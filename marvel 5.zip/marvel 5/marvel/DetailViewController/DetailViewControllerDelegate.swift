//
//  DetailViewControllerDelegate.swift
//  marvel
//
//  Created by iOSLab on 18/07/24.
//

import Foundation
protocol DetailViewControllerDelegate {
    func getHero() -> Hero?
}
