//
//  ViewController.swift
//  marvel
//
//  Created by iOSLab on 27/06/24.
//

import UIKit

class ViewController: UIViewController {
    private let network = APINetwork()
    var lastIndexPath: Int? = nil
    
    var heroes: [Hero] = []

    @IBOutlet weak var loader: UIActivityIndicatorView!
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        network.getHeroes { heroes in //closure estudar 
            DispatchQueue.main.async {
                self.heroes = heroes
                self.tableView.reloadData()
                self.loader.stopAnimating()
            }
            
        } onError: { error in
            DispatchQueue.main.async {
                self.loader.stopAnimating()
            }
            //error
        }

        tableView.dataSource  = self
        tableView.delegate = self
    }
}


