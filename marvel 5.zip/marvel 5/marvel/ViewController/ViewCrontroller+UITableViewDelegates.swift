//
//  ViewCrontroller+UITableViewDelegates.swift
//  marvel
//
//  Created by iOSLab on 27/06/24.
//

import UIKit




extension ViewController: UITableViewDelegate {
    //Clique do usuário e redirect da tela de detalhes
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        lastIndexPath = indexPath.row
        let storyboard = UIStoryboard(name: Constants.storyboardName, bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: Constants.detailViewControllerName)
        guard let detailVC = vc as? DetailViewController else {
            return
        }
        
        detailVC.delegate = self
        navigationController?.pushViewController (detailVC, animated: true)
    }
}

extension ViewController: UITableViewDataSource {
    //Devolve a quantidade de células da table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        heroes.count
    }
    //Cria nossa célula de herói
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: Constants.heroCellName, for: indexPath)
        guard let heroCell = cell as? HeroCell else {
         return cell
        }
        heroCell.delegate = self
        let hero = heroes[indexPath.row]
        heroCell.setup(hero: hero, index: indexPath.row)
        return heroCell
    }
    //Tamanho de altura de cada uma das células
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        Constants.heroCellHeight
    }
}
