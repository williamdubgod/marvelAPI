//
//  HeroCell.swift
//  marvel
//
//  Created by iOSLab on 04/07/24.
//

import UIKit

protocol HeroCellDelegate {
    func saveImageHero(image: Data, index: Int)
}

class HeroCell: UITableViewCell{
    private let network = APINetwork()
    @IBOutlet weak var imageInput: UIImageView!
    @IBOutlet weak var nameInput: UILabel!
    var delegate: HeroCellDelegate?
    
    func setup(hero: Hero, index: Int) {
        nameInput.text = hero.name
        network.getData(path: hero.imagePath) { imageData in
            DispatchQueue.main.async {
                self.delegate?.saveImageHero(image: imageData, index: index)
                let image = UIImage(data: imageData)
                self.imageInput.image = image
            }
        } onError: { error in
            debugPrint(error)
        }
    }
}
